from fastapi import FastAPI
from pymongo import MongoClient
import hvac

app = FastAPI()

# Hardcoded Vault config (for demo)
VAULT_ADDR = "http://44.206.238.59:8200"
VAULT_TOKEN = "hvs.EjV9B2xt8FC7EYH40oM79y7O"

# Connect to Vault
vault_client = hvac.Client(url=VAULT_ADDR, token=VAULT_TOKEN)

# KV v2 read: mount_point="secret", path="mongodb"
secret = vault_client.secrets.kv.v2.read_secret_version(mount_point="secret", path="mongodb")

# Extract MongoDB URI
mongodb_uri = secret["data"]["data"]["uri"]

# Connect to MongoDB Atlas
client = MongoClient(mongodb_uri)
db = client["myapp"]

@app.get("/")
def root():
    return {"message": f"Connected to MongoDB Atlas DB: {db.name}"}
